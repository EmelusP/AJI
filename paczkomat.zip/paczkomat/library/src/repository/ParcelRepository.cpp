//
// Created by barto on 10.06.2024.
//

#include "../../include/repository/ParcelRepository.h"

void ParcelRepository::addParcel(const ParcelPtr& parcel) {
    if (parcel != nullptr)
        parcels.push_back(parcel);
}

void ParcelRepository::removeParcel(const ParcelPtr& parcel) {
    for(int i = 0; i < parcels.size();i++){
        if(parcels[i] == parcel){
            parcels.erase(parcels.begin()+i);
        }
    }
}

const std::vector<ParcelPtr> &ParcelRepository::getParcels() const {
    return parcels;
}

ParcelRepository::ParcelRepository() {}

ParcelRepository::~ParcelRepository() {

}

const ParcelPtr ParcelRepository::getParcelByID(int id) const {
    if (parcels.empty())
        return nullptr;
    for (int i = 0; i < parcels.size(); i++) {
        if (parcels[i]->getParcelId() == id)
            return parcels[i];
    }
    return nullptr;
}
