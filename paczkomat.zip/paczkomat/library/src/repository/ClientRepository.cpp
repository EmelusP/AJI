#include "../../include/repository/ClientRepository.h"

void ClientRepository::addClient(const ClientPtr& client) {
    if (client != nullptr) {
        clients.push_back(client);
    }
}

void ClientRepository::removeClient(const ClientPtr& client) {
    for(int i = 0; i < clients.size();i++){
        if(clients[i] == client){
            clients.erase(clients.begin()+i);
        }
    }
}

const std::vector<ClientPtr> &ClientRepository::getClients() const {
    return clients;
}

ClientRepository::ClientRepository() {}

ClientRepository::~ClientRepository() {

}

const ClientPtr ClientRepository::getClientByID(int id) const {
    if (clients.empty())
        return nullptr;
    for (int i = 0; i < clients.size(); i++) {
        if (clients[i]->getPersonalID() == id)
            return clients[i];
    }
    return nullptr;
}
