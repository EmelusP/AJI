//
// Created by barto on 10.06.2024.
//

#include "../../include/repository/PaczkomatRepository.h"

void PaczkomatRepository::addPaczkomat(const PaczkomatPtr& paczkomat) {
    if (paczkomat != nullptr)
        paczkomaty.push_back(paczkomat);
}

bool PaczkomatRepository::removePaczkomat(const PaczkomatPtr& paczkomat) {
    for(int i = 0; i < paczkomaty.size();i++){
        if(paczkomaty[i] == paczkomat){
            paczkomaty.erase(paczkomaty.begin()+i);
            return true;
        }
    }
    return false;
}

const std::vector<PaczkomatPtr> &PaczkomatRepository::getPaczkomaty() const {
    return paczkomaty;
}

PaczkomatRepository::PaczkomatRepository() {}

PaczkomatRepository::~PaczkomatRepository() {

}

const PaczkomatPtr PaczkomatRepository::getPaczkomatByID(int id) const {
    if (paczkomaty.empty())
        return nullptr;
    for (int i = 0; i < paczkomaty.size(); i++) {
        if (paczkomaty[i]->getId() == id)
            return paczkomaty[i];
    }
    return nullptr;
}
