//
// Created by barto on 11.06.2024.
//

#include "../../include/manager/ParcelManager.h"

bool ParcelManager::checkParcel(const ParcelPtr &parcel) const {
    std::vector<ParcelPtr> parcels = parcelRepo.getParcels();
    bool czyJest = false;
    if (parcel != nullptr)
    {
        for (int i = 0; i < parcels.size(); i++)
        {
            if (parcels[i] == parcel)
                czyJest = true;
        }
        if(czyJest)
            return true;
    }
    return false;
}

int ParcelManager::countParcels() const {
    return parcelRepo.getParcels().size();
}

bool ParcelManager::createParcel(const ParcelPtr& parcel) {
    parcelRepo.addParcel(parcel);
    return checkParcel(parcel);
}


ParcelManager::~ParcelManager() {

}

bool ParcelManager::delieverParcel(int parcelId) {
    if (parcelRepo.getParcelByID(parcelId))
        return parcelRepo.getParcelByID(parcelId)->delieverParcel(boost::posix_time::second_clock::local_time());
    return false;
}

void ParcelManager::deleteParcel(int id) {
    parcelRepo.removeParcel(getParcelByID(id));
}

const ParcelPtr ParcelManager::getParcelByID(int id) const {
    return parcelRepo.getParcelByID(id);
}

ParcelManager::ParcelManager() {}

const std::string ParcelManager::getInfo(int id) {
    std::stringstream out;
    if (getParcelByID(id)) {
        out << getParcelByID(id)->getInfo();
        return out.str();
    }
    out << "Paczka o podanym id nie istnieje.\n";
    return out.str();
}
