//
// Created by barto on 11.06.2024.
//

#include "../../include/manager/PaczkomatManager.h"

bool PaczkomatManager::checkPaczkomat(const PaczkomatPtr &paczkomat) const {
    std::vector<PaczkomatPtr> paczkomaty = paczkomatRepo.getPaczkomaty();
    if (paczkomat != nullptr) {
        bool czyJest = false;
        if (paczkomat != nullptr) {
            for (int i = 0; i < paczkomaty.size(); i++) {
                if (paczkomaty[i] == paczkomat)
                    czyJest = true;
            }
        }
        return (czyJest);
    }
    return false;
}

int PaczkomatManager::countPaczkomaty() const {
    return paczkomatRepo.getPaczkomaty().size();
}


PaczkomatManager::~PaczkomatManager() {

}

bool PaczkomatManager::createPaczkomat(const std::string &address, const std::string &region) {
    if (!address.empty() || !region.empty()) {
        PaczkomatPtr paczkomat = std::make_shared<Paczkomat>(region, address, currentPaczkomatId++);
        paczkomatRepo.addPaczkomat(paczkomat);
        std::cout << "Ustawiono id paczkomatu na: " << std::to_string(currentPaczkomatId - 1) << std::endl;
        return checkPaczkomat(paczkomat);
    }
    return false;
}

bool PaczkomatManager::addLockers(Size size, int amount, int id) {
    if (getPaczkomatByID(id)) {
        if (amount > 0) {
            std::shared_ptr<Lockers> lockers = std::make_shared<Lockers>(size, amount);
            if (getPaczkomatByID(id)->addLockers(lockers))
                return true;
            return expandLockers(size, amount, id);
        }
    }
    return false;
}

bool PaczkomatManager::expandLockers(Size size, int amount, int id) {
    int amountToAdd = getPaczkomatByID(id)->getLockersAmount(size);
    deleteLockers(size, id);
    return addLockers(size, amount + amountToAdd, id);
}

void PaczkomatManager::deleteLockers(Size size, int id) {
    getPaczkomatByID(id)->removeLockers(size);
}

const PaczkomatPtr PaczkomatManager::getPaczkomatByID(int id) const {
    return paczkomatRepo.getPaczkomatByID(id);
}

bool PaczkomatManager::deletePaczkomat(int id) {
    if(paczkomatRepo.removePaczkomat(getPaczkomatByID(id))){
     return true;
    }
    else
    {
        return false;
    }
}

PaczkomatManager::PaczkomatManager() {}

const std::string PaczkomatManager::getInfo(int id) {
    std::stringstream out;
    if (getPaczkomatByID(id)) {
        out << getPaczkomatByID(id)->getInfo();
        return out.str();
    }
    out << "Paczkomat o podanym id nie istnieje.\n";
    return out.str();
}
