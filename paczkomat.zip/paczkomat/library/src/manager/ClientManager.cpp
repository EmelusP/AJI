#include "../../include/manager/ClientManager.h"


ClientManager::~ClientManager() {

}

bool ClientManager::checkClient(const ClientPtr &client) const {
    return clientRepo.getClientByID(client->getPersonalID()) != nullptr;
}

int ClientManager::countClients() const {
    return clientRepo.getClients().size();
}


bool ClientManager::createClient(const std::string &firstName, const std::string &lastName, CType clientType) {
    std::shared_ptr<BusinessClient> bType = std::make_shared<BusinessClient>();
    std::shared_ptr<PrivateClient> pType = std::make_shared<PrivateClient>();
    ClientPtr newClient = std::make_shared<Client>(firstName, lastName, currentClientId++, bType);
    switch (clientType) {
        case Business: {
            newClient->setClientType(bType);
            break;
        }
        case Private: {
            newClient->setClientType(pType);
            break;
        }
        default:
            return false;
    }
    clientRepo.addClient(newClient);
    std::cout << "Ustawiono id clienta na: " << std::to_string(currentClientId - 1) << std::endl;
    return checkClient(newClient);
}

bool ClientManager::sendParcel(int senderId, int recepientId, Size size, int destinationId) {
    try {
        if (countClients() < 2)
            throw std::invalid_argument("Nie istnieje wystarczajaco klientow!");

        ClientPtr sender = getClientByID(senderId);
        ClientPtr recepient = getClientByID(recepientId);
        PaczkomatPtr destination = paczkomatManago->getPaczkomatByID(destinationId);

        if (!sender || !recepient )
            throw std::invalid_argument("Nie istnieje klient o podanym ID!");

        if (!destination)
            throw std::invalid_argument("Nie istnieje paczkomat o podanym ID!");

        ParcelPtr parcel = std::make_shared<Parcel>(currentParcelId++, sender, recepient, size, destination);

        if (parcelManago->createParcel(parcel))
            std::cout << "Ustawiono id paczki na: " << std::to_string(currentParcelId - 1) << std::endl;

        return sender->sendParcel(parcel, boost::posix_time::second_clock::local_time());
    }
    catch (std::exception& err) {
        std::cout << "Blad! " << err.what() << std::endl;
        return false;
    }
}

bool ClientManager::collectParcel(int recepientId, int parcelId) {
    return getClientByID(recepientId)->collectParcel(parcelId, boost::posix_time::second_clock::local_time());
}

void ClientManager::deleteClient(int id) {
    clientRepo.removeClient(clientRepo.getClientByID(id));
}

ClientManager::ClientManager(const std::shared_ptr<PaczkomatManager> &paczkomatManago,
                             const std::shared_ptr<ParcelManager> &parcelManago) : paczkomatManago(paczkomatManago),
                                                                                   parcelManago(parcelManago) {}

const ClientPtr ClientManager::getClientByID(int id) const {
    return clientRepo.getClientByID(id);
}

const std::string ClientManager::getInfo(int id) {
    std::stringstream out;
    if (getClientByID(id)) {

        out << getClientByID(id)->getInfo();
        return out.str();
    }
    out << "Klient o podanym id nie istnieje.\n";
    return out.str();
}









