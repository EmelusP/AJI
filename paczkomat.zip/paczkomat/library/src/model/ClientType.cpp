//
// Created by student on 09.06.24.
//

#include "../../include/model/ClientType.h"


ClientType::ClientType() {}

ClientType::~ClientType() {

}


