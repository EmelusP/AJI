//
// Created by student on 09.06.24.
//

#include "../../include/model/PrivateClient.h"

const int PrivateClient::maxParcelsSent() {
    return maxPackages;
}

PrivateClient::PrivateClient()  = default;

const std::string PrivateClient::getInfo() {
    std::stringstream out;
    out << " Typ klienta: Prywatny";
    return out.str();
}
