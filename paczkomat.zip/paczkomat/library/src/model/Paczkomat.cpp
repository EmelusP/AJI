//
// Created by student on 09.06.24.
//

#include "../../include/model/Paczkomat.h"

bool Paczkomat::occupyLocker(Size size) { //na razie funkcja zajmuje locker tylko o size'ie paczki
    for (int i = 0; i < lockersGroup.size(); i++)
    {
        if (size == lockersGroup[i]->getSize())
        {
            bool flag = lockersGroup[i]->occupy();
            return flag;
        }
    }
    return false;
}

void Paczkomat::freeLocker(Size size) {
    for (int i = 0; i < lockersGroup.size(); i++)
    {
        if(lockersGroup[i]->getSize() == size)
            lockersGroup[i]->free();
    }
}

Paczkomat::Paczkomat(const std::string &region, const std::string &address, int id) : region(region), address(address), id(id) {}

bool Paczkomat::addLockers(const LockersPtr &lockers) {
    if (lockers != nullptr)
    {
        for (int i = 0; i < lockersGroup.size(); i++)
        {
            if (lockersGroup[i] == lockers || lockersGroup[i]->getSize() == lockers->getSize()) //jezeli paczkomat stoi to nie dolutujesz dodatkowych skrytek
                return false;
        }
        lockersGroup.push_back(lockers);
        return true;
    }
    return false;
}

const std::string Paczkomat::getInfo() {
    std::stringstream out;
    out << "\nPaczkomat\nID: " << getId() << "Region: " << "\nAdres: " << getAddress();
    for (int i = 0; i < lockersGroup.size(); i++)
    {
        out << lockersGroup[i]->getInfo();
    }
    out << "\n";
    return out.str();
}

const std::string &Paczkomat::getRegion() const {
    return region;
}

const std::string &Paczkomat::getAddress() const {
    return address;
}

bool Paczkomat::isFree(Size size) {
    for (int i = 0; i < lockersGroup.size(); i++)
    {
        if (lockersGroup[i]->getSize() == size)
        {
            return lockersGroup[i]->areAnyAvailable();
        }
    }
    return false;
}

Paczkomat::~Paczkomat() {

}

void Paczkomat::removeLockers(Size size) {
    for (int i = 0; i < lockersGroup.size(); i++) {
        if (lockersGroup[i]->getSize() == size) {
            lockersGroup.erase(lockersGroup.begin() + i);
            return;
        }
    }
}

int Paczkomat::getId() const {
    return id;
}

void Paczkomat::setId(int id) {
    Paczkomat::id = id;
}

int Paczkomat::getLockersAmount(Size size) const {
    int amount = 0;
    for (int i = 0; i < lockersGroup.size(); i++) {
        if(lockersGroup[i]->getSize() == size) {
            amount = lockersGroup[i]->getAmount();
        }
    }
    return amount;
}
