//
// Created by student on 09.06.24.
//

#include "../../include/model/Lockers.h"


bool Lockers::areAnyAvailable() {
    if(amountAvailable > 0){
        return true;
    }
    else return false;
}

bool Lockers::occupy() {
    if(this->areAnyAvailable()){//po co sprawdzac rozmiar jezeli occupy przy paczkomacie go sprawdza?
        amountAvailable--;
        return true;
    }
    return false;
}

void Lockers::free() {
    if (amountAvailable < amount) {
        amountAvailable++;
    }
}
// sprawdzić instrukcje


int Lockers::getSize() {
    return size;
}

Lockers::Lockers(Size size, int amount) : size(size), amount(amount), amountAvailable(amount) {
}

Lockers::~Lockers() {

}

const std::string Lockers::getInfo() {
    std::stringstream out;
    out << "\nSkrytki\nRozmiar: " << std::to_string(size) << "\nIlosc: " <<  std::to_string(amount)
    << "\nIlosc dostepnych: " << std::to_string(amountAvailable) << "\n";
    return out.str();
}

int Lockers::getAmountAvailable() const {
    return amountAvailable;
}

int Lockers::getAmount() const {
    return amount;
}



