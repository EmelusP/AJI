//
// Created by student on 09.06.24.
//

#include "../../include/model/Parcel.h"

void Parcel::sendParcel(const PTimeClass &postageDate) {
    Parcel::postageDate = postageDate;
}

Parcel::Parcel(int parcelId, const ClientPtr &sender, const ClientPtr &recepient, Size size,
               const PaczkomatPtr &destination) : parcelID(parcelId), sender(sender), recepient(recepient), size(size),
                                                  destination(destination) {}

Parcel::~Parcel() {

}

bool Parcel::delieverParcel(const PTimeClass &delieveryDateTemp) {
    if(delieveryDateTemp > postageDate && destination->isFree(size))
    {
        Parcel::delieveryDate = delieveryDateTemp;
        Parcel::receiptLimit = delieveryDateTemp + boost::posix_time::hours(48);
        isDelievered = true;
        destination->occupyLocker(size);
        return true;
    }
    return false;
}

bool Parcel::collectParcel(const PTimeClass &collectionDate) {
    if (isDelievered)
    {
        sender->eraseSentParcelByID(getParcelId());
        destination->freeLocker(size);
        isCollected = (collectionDate <= receiptLimit);
        if (!isCollected)
        {
            recepient->eraseRecievedParcelByID(getParcelId());
        }
        else
        {
            collectDate = collectionDate;
        }
        return isCollected;
    }
    return false;
}

const ClientPtr &Parcel::getRecepient() const {
    return recepient;
}

const std::string Parcel::getInfo() {
    std::stringstream out;
    out << "\nPaczka\nId: " << std::to_string(parcelID) << "\nRozmiar: " << std::to_string(size) << "\nNadawca: "
    << sender->getFirstName() << " " << sender->getLastName() << " ID: " << std::to_string(sender->getPersonalID())
    << "\nAdresat: " << recepient->getFirstName() << " "
    << recepient->getLastName() << " ID: " << std::to_string(recepient->getPersonalID())
    << "\nDaty:\nNadania: " << to_simple_string(postageDate) << "\nDostarczenia do paczkomatu: " <<
    to_simple_string(delieveryDate) << "\nLimitu odbioru: " << to_simple_string(receiptLimit)
    << "\nOdbioru: " << to_simple_string(collectDate) << "\nCzy zostala dostarczona? " << ((isDelievered) ? "tak":"nie")
    << "\nCzy zostala odebrana? " << ((isCollected) ? "tak":"nie") << destination->getInfo();
    return out.str();
}

void Parcel::setParcelId(int parcelId) {
    parcelID = parcelId;
}

int Parcel::getParcelId() const {
    return parcelID;
}

const PTimeClass &Parcel::getReceiptLimit() const {
    return receiptLimit;
}

bool Parcel::isParcelCollected() const {
    return isCollected;
}

bool Parcel::isParcelDelievered() const {
    return isDelievered;
}

const ClientPtr &Parcel::getSender() const {
    return sender;
}
