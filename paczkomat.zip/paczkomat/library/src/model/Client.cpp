//
// Created by student on 09.06.24.
//

#include "../../include/model/Client.h"



std::string Client::getFirstName() const {
    return firstName;
}

std::string Client::getLastName() const {
    return lastName;
}

int Client::getPersonalID() const {
    return personalID;
}

// Send Parcel
bool Client::sendParcel(const ParcelPtr& parcel, const PTimeClass &postageDate) {
    try {
        if (!parcel)
            throw std::invalid_argument("Parcel nie istnieje");
        if (clientType->maxParcelsSent() <= sentPackages.size())
            throw std::overflow_error("Klient nie moze wyslac paczki przez limit");
        if (parcel->getSender()->getPersonalID() != getPersonalID())
            throw std::logic_error("Klient nie jest nadawca paczki!");
        if (std::find(sentPackages.begin(), sentPackages.end(), parcel) != sentPackages.end()
            || parcel->isParcelCollected()
            || parcel->isParcelDelievered())
            throw std::logic_error("Paczka juz zostala wyslana!");
        sentPackages.push_back(parcel);
        parcel->sendParcel(postageDate);
        parcel->getRecepient()->recieveParcel(parcel);
        return true;
    }
    catch(std::exception& err) {
        std::cout << "Blad! " << err.what() << std::endl;
        return false;
    }
}

// Collect Parcel
bool Client::collectParcel(int id, const PTimeClass &collectionDate) {
    ParcelPtr parcel = getRecievedPackageByID(id);
    if (parcel && std::find(recievedPackages.begin(), recievedPackages.end(), parcel) != recievedPackages.end())
        return parcel->collectParcel(collectionDate);
    return false;
}

const std::string Client::getInfo() {
    std::stringstream out;
    out << "Informacje o osobie:\nImie i nazwisko: "<< getFirstName()<< " "<< getLastName()<<"\nID: "<<getPersonalID()
    << "\n" << clientType->getInfo() << "\nPaczki otrzymane:\n";
    for (int i = 0; i < recievedPackages.size(); i++)
    {
        out << recievedPackages[i]->getInfo();
    }
    out << "Paczki wyslane:\n";
    for (int i = 0; i < sentPackages.size(); i++)
    {
        out << sentPackages[i]->getInfo();
    }
    out << "\n";
    return out.str();
}

Client::Client(const std::string &firstName, const std::string &lastName, int personalId,
               const std::shared_ptr<ClientType> &clientType) : firstName(firstName), lastName(lastName),
                                                                personalID(personalId), clientType(clientType) {}

Client::~Client() {

}

void Client::eraseSentParcelByID(int id) {
    for (int i = 0; i < sentPackages.size(); i++)
    {
        if (sentPackages[i]->getParcelId() == id)
        {
                sentPackages.erase(sentPackages.begin()+i);
                return;
        }
    }
}

void Client::eraseRecievedParcelByID(int id) {
    for (int i = 0; i < recievedPackages.size(); i++)
    {
        if (recievedPackages[i]->getParcelId() == id)
        {
            recievedPackages.erase(recievedPackages.begin()+i);
            return;
        }
    }
}

void Client::recieveParcel(const ParcelPtr &parcel) {
    if(parcel != nullptr)
        recievedPackages.push_back(parcel);
}

void Client::setClientType(const std::shared_ptr<ClientType> &clientType) {
    Client::clientType = clientType;
}


const std::shared_ptr<ClientType> &Client::getClientType() const {
    return clientType;
}

const ParcelPtr Client::getSentPackageByID(int id) const {
    if (!sentPackages.empty()) {
            for (int i = 0; i < sentPackages.size(); i++) {
                if (sentPackages[i]->getParcelId() == id)
                    return sentPackages[i];
            }
    }
    return nullptr;
}

const ParcelPtr Client::getRecievedPackageByID(int id) const {
    if (!recievedPackages.empty()) {
        for (int i = 0; i < recievedPackages.size(); i++) {
            if (recievedPackages[i]->getParcelId() == id)
                return recievedPackages[i];
        }
    }
    return nullptr;
}


