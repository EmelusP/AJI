//
// Created by student on 09.06.24.
//

#include "../../include/model/BusinessClient.h"

const std::string BusinessClient::getInfo() {
    std::stringstream out;
    out<< " Typ klienta: Biznesowy";
    return out.str();
}

BusinessClient::BusinessClient() {

}

const int BusinessClient::maxParcelsSent() {
    return maxPackages;
}
