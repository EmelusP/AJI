// UI.cpp
#include "../../include/ui/UI.h"
#include <boost/date_time/posix_time/posix_time.hpp>
#include <filesystem>

UI::UI(){
    try{
        //logi w cmake-build-debug/logs/logfile.txt tworzy się przy uruchomieniu
        std::filesystem::create_directories("../logs");
        std::string logFileName = "../logs/logfile.txt";
        plog::init(plog::debug, logFileName.c_str());

        std::shared_ptr<ParcelManager> parcelManago = std::make_shared<ParcelManager>();
        std::shared_ptr<PaczkomatManager> paczkomatManago = std::make_shared<PaczkomatManager>();
        std::shared_ptr<ClientManager> clientManago = std::make_shared<ClientManager>(paczkomatManago, parcelManago);

        PLOG_INFO << "Inicjalizacja UI zakończona pomyślnie.";
    } catch (const std::exception& e) {
        PLOG_ERROR << "Wyjątek podczas inicjalizacji UI: " << e.what();
        std::cerr << "Wyjątek podczas inicjalizacji UI: " << e.what() << std::endl;
    } catch (...) {
        PLOG_ERROR << "Nieznany wyjątek podczas inicjalizacji UI.";
        std::cerr << "Nieznany wyjątek podczas inicjalizacji UI." << std::endl;
    }
}


void UI::displayMenu() {
    std::stringstream out;
    out << "========MENU========\n";
    out << "Dostępne opcje:\n";
    out << "1. Dodaj klienta prywatnego\n";
    out << "2. Dodaj klienta biznesowego\n";
    out << "3. Wyślij paczkę\n";
    out << "4. Dostarcz paczkę\n";
    out << "5. Odbierz paczkę\n";
    out << "6. Wyświetl informacje o klientach\n";
    out << "7. Utwórz paczkomat \n";
    out << "8. Usuń paczkomat \n";
    out << "9. Zmien ilosc skrytek w paczkomacie\n";
    out << "10. Usuń klienta\n";
    out << "11. Zakończ program\n";
    out << "====================\n";
    std::cout << out.str();
}
// try-catch aby wyłapać możliwe wyjątki i błedy przy obsłudze UI
int UI::run() {
    try {
        PLOG_INFO<< "Rozpoczęcie uruchamiania UI.";
        int wybor;
        while (true) {
            displayMenu();
            std::cout << "Wybierz opcje: ";
            std::cin >> wybor;
            switch (wybor) {
                case 1:
                    addPrivateClient();
                    break;
                case 2:
                    addBusinessClient();
                    break;
                case 3:
                    sendParcel();
                    break;
                case 4:
                    dostarczPaczke();
                    break;
                case 5:
                    collectParcel();
                    break;
                case 6:
                    displayClients();
                    break;
                case 7:
                    utworzPaczkomat();
                    break;
                case 8:
                    usunPaczkomat();
                    break;
                case 11:
                    return 0;
                case 9:
                    zmianaParam();
                    break;
                case 10:
                    usunKlienta();
                    break;
                default:
                    std::cout << "\nNieznana opcja, spróbuj ponownie." << std::endl;
            }
        }
        PLOG_INFO << "Uruchomienie zakończone powodzeniem.";
    }
    catch (const std::exception& err) {
        PLOG_ERROR << "Uruchomienie zakończone niepowodzenime:" << err.what() <<std::endl;
        std::cerr <<"\nUruchomienie zakończone niepowodzeniem:"<<err.what()<<std::endl;
        return 1;
    }
    catch(...){
        PLOG_ERROR << "Uruchomienie zakończone nieznanym niepowodzeniem." ;
        std::cerr <<"\nUruchomienie zakończone nieznanym niepowodzeniem."<<std::endl;
        return 1;
    }
    return 0;
}

void UI::addPrivateClient() {
    try {
        std::string imie, nazwisko;
        int ID;
        std::cout << "Podaj imie: \n";
        std::cin >> imie;
        std::cout << "Podaj nazwisko: \n";
        std::cin >> nazwisko;

        clientManago->createClient(imie, nazwisko, Private);
        PLOG_INFO << "Utworzenie klienta prywatnego zakończona sukcesem";
    }
    catch (std::exception& err) {
        PLOG_ERROR << "Utworzenie klienta prywatnego zakończona błędem:" << err.what();
        std::cerr << "Utworzenie klienta prywatnego zakończona błędem:" << err.what()<<std::endl;
    }
}

void UI::addBusinessClient() {
    try {
        std::string imie, nazwisko;
        int ID;
        std::cout << "Podaj imie: \n";
        std::cin >> imie;
        std::cout << "Podaj nazwisko: \n";
        std::cin >> nazwisko;

        clientManago->createClient(imie, nazwisko, Business);
        PLOG_INFO << "Utworzenie klienta biznesowego zakończona sukcesem";
    }
    catch (std::exception& err) {
        PLOG_ERROR << "Utworzenie klienta biznesowego zakończona błędem:" << err.what();
        std::cerr << "Utworzenie klienta biznesowego zakończona błędem:" << err.what()<<std::endl;
    }
}

void UI::sendParcel() {
    int IDkn;
    int IDko;
    int IDp;
    std::string sizeInput;
    Size size;

    std::cout << "Podaj ID klienta nadawcy: ";
    std::cin >> IDkn;
    std::cout << "Podaj ID klienta odbiorcy: ";
    std::cin >> IDko;
    std::cout << "Podaj ID paczkomatu: ";
    std::cin >> IDp;
    std::cout << "Podaj rozmiar paczki (S, M, L): ";
    std::cin >> sizeInput;

    size = parametry(sizeInput);
    try {
        plog::init(plog::debug,"../paczkomat/logs/logfile.txt");
        ClientPtr sender = clientManago->getClientByID(IDkn);
        ClientPtr recipient = clientManago->getClientByID(IDko);
        if (sender == nullptr || recipient == nullptr) {
            throw std::invalid_argument("Nie znaleziono klienta o podanym ID");
        }
        if (clientManago->sendParcel(IDkn,IDko,size,IDp)) {
            std::cout << "\nPaczka wysłana." << std::endl;
        } else {
            std::cout << "\nNie udało się wysłać paczki." << std::endl;
        }
        PLOG_INFO << "Wysłanie paczki zakończona sukcesem";
    }
    catch (std::exception& err) {
        PLOG_ERROR << "Wysłanie paczki zakończona błędem:" << err.what();
        std::cerr << "Wysłanie paczki zakończona błędem:" << err.what()<<std::endl;
    }


}

void UI::collectParcel() {
    int IDk;
    int IDp;
    std::cout << "\nPodaj ID klienta: ";
    std::cin >> IDk;
    std::cout << "\nPodaj ID paczki: ";
    std::cin >> IDp;

    if(clientManago->collectParcel(IDk,IDp)){
        std::cout<<"\nUdało się odebrać paczkę.\n";
    }
    else
    {
        std::cout<<"\nNie udało się odebrać paczki.\n";
    }
}

void UI::displayClients() {
    std::cout << "===Informacje o klientach ===\n";
    std::string out;
    for(int i = 1;i<= clientManago->countClients();i++) {
        out +=clientManago->getInfo(i)+"\n";
    }
    std::cout << out;
    std::cout << "=============================\n";
}

void UI::utworzPaczkomat() {
    std::string adres;
    std::string region;
    int id;
    std::cout<< "\nPodaj adres: ";
    std::cin >> adres;
    std::cout<< "\nPodaj region: ";
    std::cin >> region;
    if(paczkomatManago->createPaczkomat(adres,region))
    {
        std::cout<<"\nPaczkomat utowrzony.\n" ;
    }
    else
    {
        std::cout<< "\nNie udało się utworzyć paczkomatu.\n";
    }
}

void UI::usunPaczkomat() {
    int id;
    std::cout<< "Podaj id paczkomatu który chcesz usunąć: ";
    std::cin>>id;
    if(paczkomatManago->deletePaczkomat(id)){
        std::cout<< "\nUdało się usunąć paczkomat.\n";
    }
    else{
        std::cout<< "\nNie udało się usunąć paczkomatu.\n";
    }

}

void UI::zmianaParam() {
    int id;
    std::cout<< "Podaj id paczkomatu do modyfikacji:";
    std::cin >> id;
    int operacja;
    std::cout << "\nPodaj jaką operacje chcesz wykonać 1) dadaj skrytki 2) usun wszystkie skrytki\n";
    std::cin>>operacja;
    if(operacja == 1){
        int liczba;
        std::string size;
        Size sizei;
        std::cout <<"\nPodaj liczbę skrytek które chcesz dodać:";
        std::cin >> liczba;
        std::cout<< "\n Jakiego rozmiaru mają być skrytki (S,M,L):";
        std::cin >> size;
        sizei = parametry(size);
        if(paczkomatManago->addLockers(sizei,liczba, id)){
            std::cout << "\nOperacja udana.\n";
        }
        else {
            std::cout << "\nOperacja nieudana.\n";
        }
    }
    else if(operacja == 2){
        std::string size;
        Size sizei;
        std::cout<< "\n Jakiego rozmiaru skrytki maja byc usuniete (S,M,L):";
        std::cin >> size;
        sizei = parametry(size);
        paczkomatManago->deleteLockers(sizei, id);
        std::cout << "\nOperacja wykonana. \n";

    }
    else
    {
        std::cout <<"\nNie ma takiej operacji. \n";
    }

}

Size UI::parametry(std::string size) {
    Size size1;
    try {
        if (size == "S" || size == "s") {
            return S;
        } else if (size == "M" || size == "m") {
            return M;
        } else if (size == "L" || size == "l") {
            return L;
        } else {
            throw std::invalid_argument("Podano bledny rozmiar");
        }
        PLOG_INFO << "Ustawianie rozmiaru zakończone sukcesem";
    }
    catch (std::exception& err) {
        PLOG_ERROR << "Ustawianie rozmiaru zakończone błędem:" << err.what();
        std::cerr << "Ustawianie rozmiaru zakończone błędem:" << err.what()<<std::endl;
    }

}

void UI::usunKlienta() {
    int id;
    std::cout<< "\nPodaj id klienta którego chcesz usunąć:";
    std::cin >> id;
    clientManago->deleteClient(id);
    std::cout << "\nKlient usunięty\n";
}

void UI::dostarczPaczke() {
    try {
        int idP;
        std::cout<<"Podaj ID paczki do dostarczenia:";
        std::cin>>idP;
        if(parcelManago->delieverParcel(idP) != true){
            throw std::logic_error("Uzytkownik probowal dostarczyc nieistniejaca paczke");
        }
        else{
            std::cout<<"\nPaczka dostarczona\n";
        }
        PLOG_INFO << "Operacja dostarczenia paczki powiodła się.";
    }
    catch(std::exception& err){
        PLOG_ERROR << "Dostarczanie paczki zakończone błędem:" << err.what();
        std::cerr << "Dostarczanie paczki zakończone błędem:" << err.what()<<std::endl;
    }
}
