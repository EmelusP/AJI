//
// Created by student on 09.06.24.
//

#ifndef PACZKOMAT_PRIVATECLIENT_H
#define PACZKOMAT_PRIVATECLIENT_H
#include "ClientType.h"

class PrivateClient: public ClientType {
private:
    int maxPackages = 3;
public:
    PrivateClient();
    const std::string getInfo() override;
    const int maxParcelsSent() override;
};


#endif //PACZKOMAT_PRIVATECLIENT_H
