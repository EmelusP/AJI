//
// Created by student on 09.06.24.
//

#ifndef PACZKOMAT_CLIENTTYPE_H
#define PACZKOMAT_CLIENTTYPE_H
#include "../typedefs.h"

class ClientType{
private:
public:
    ClientType();
    virtual const int maxParcelsSent() = 0;
    virtual const std::string getInfo() = 0;

    virtual ~ClientType();
};


#endif //PACZKOMAT_CLIENTTYPE_H
