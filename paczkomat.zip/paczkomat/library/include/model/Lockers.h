//
// Created by student on 09.06.24.
//

#ifndef PACZKOMAT_LOCKERS_H
#define PACZKOMAT_LOCKERS_H
#include "../typedefs.h"

class Lockers { //Klasa zajmuje sie glownie liczeniem, paczki przetrzymywane sa w klasie paczkomat
private:
    Size size;
    int amount;
    int amountAvailable;
public:
    bool areAnyAvailable(); //sprawdza czy amountAvailable != 0
    bool occupy(); //dekrementuje amountAvailable jesli != 0
    void free(); //inkrementuje amountAvailable jesli != amount
    int getSize(); // getter
    const std::string getInfo(); //getter zwracajacy cale info w postaci stringa
    int getAmountAvailable() const; //getter
    int getAmount() const; //getter

    Lockers(Size size, int amount);
    virtual ~Lockers();
};


#endif //PACZKOMAT_LOCKERS_H
