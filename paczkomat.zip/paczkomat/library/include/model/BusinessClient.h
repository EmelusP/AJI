//
// Created by student on 09.06.24.
//

#ifndef PACZKOMAT_BUSINESSCLIENT_H
#define PACZKOMAT_BUSINESSCLIENT_H
#include "ClientType.h"

class BusinessClient: public ClientType {
private:
    int maxPackages = 10;
public:
    BusinessClient();
    const std::string getInfo() override;
    const int maxParcelsSent() override;
};


#endif //PACZKOMAT_BUSINESSCLIENT_H
