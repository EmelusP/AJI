//
// Created by student on 09.06.24.
//

#ifndef PACZKOMAT_CLIENT_H
#define PACZKOMAT_CLIENT_H
#include "../typedefs.h"
#include "sstream"
#include "ClientType.h"
#include "Parcel.h"

class Client {
private:
    std::string firstName;
    std::string lastName;
    int personalID;
    std::vector<ParcelPtr> sentPackages;
    std::vector<ParcelPtr> recievedPackages;
    std::shared_ptr<ClientType> clientType;
public:
    Client(const std::string &firstName, const std::string &lastName, int personalId,
           const std::shared_ptr<ClientType> &clientType);
    virtual ~Client();

    std::string getFirstName() const; //getter
    std::string getLastName() const; //getter
    int getPersonalID() const; //getter
    bool sendParcel(const ParcelPtr& parcel, const PTimeClass &postageDate); //wysylanie paczki; dodaje parcel do list sentPackages jesli ten client jest recepientem i ma miejsce na wyslanie paczki
    void recieveParcel(const ParcelPtr& parcel); //"otrzymanie paczki"; dodaje parcel do recievedPackages
    void eraseSentParcelByID(int id); //usuwa dany parcel z sentPackages
    void eraseRecievedParcelByID(int id); //usuwa dany parcel z recievedPackages
    bool collectParcel(int id, const PTimeClass &collectionDate); //odebranie podanej paczki o podanym czasie, wywoluje Parcel::collectParcel
    const std::string getInfo(); //getter zwracajacy pelne info jako string
    const ParcelPtr getSentPackageByID(int id) const; //getter znajdujacy paczke po id w wektorze sentPackages **uwaga na uzywanie podczas gdy wektor jest pusty, za kazdym razem ma problem**
    const ParcelPtr getRecievedPackageByID(int id) const; //getter znajdujacy paczke po id w wektorze recievedPackages **uwaga na uzywanie podczas gdy wektor jest pusty, za kazdym razem ma problem**
    const std::shared_ptr<ClientType> &getClientType() const; //getter
    void setClientType(const std::shared_ptr<ClientType> &clientType); //setter

};


#endif //PACZKOMAT_CLIENT_H
