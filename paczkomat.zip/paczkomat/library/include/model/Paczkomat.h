//
// Created by student on 09.06.24.
//

#ifndef PACZKOMAT_PACZKOMAT_H
#define PACZKOMAT_PACZKOMAT_H
#include "../typedefs.h"
#include "Lockers.h"


class Paczkomat { //brakuje miejsca dla przetrzymywania paczki
private:
    int id;
    std::string region;
    std::string address;
    std::vector<LockersPtr> lockersGroup;
public:
    bool occupyLocker(Size size); //wywoluje Lockers::occupy() dla Lockers o podanej wielkosci
    void freeLocker(Size size); //wywoluje Lockers::free() dla lockers o podanej wielkosci
    bool addLockers(const LockersPtr& lockers); //dodaje do wektora lockersGroup podany locker, musi byc unikalny wzgledem size
    void removeLockers(Size size);
    bool isFree(Size size); //wywoluje Lockers::areAnyAvailable() dla lockers o podanej wielkosci
    const std::string getInfo(); //zwraca string z info
    const std::string &getRegion() const; //getter
    const std::string &getAddress() const; //getter
    int getId() const; //getter
    int getLockersAmount(Size size) const; //getter zwracajacy amount dla danego size


    void setId(int id);

    Paczkomat(const std::string &region, const std::string &address, int id);
    virtual ~Paczkomat();
};


#endif //PACZKOMAT_PACZKOMAT_H
