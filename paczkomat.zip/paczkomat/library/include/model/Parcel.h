//
// Created by student on 09.06.24.
//

#ifndef CARRENTAL_PARCEL_H
#define CARRENTAL_PARCEL_H
#include "../typedefs.h"
#include "Client.h"
#include "Paczkomat.h"


class Parcel {
private:
    int parcelID;
    PTimeClass postageDate; //data nadania
    PTimeClass delieveryDate; //data dostarczenia do paczkomatu
    PTimeClass collectDate; //data odebrania, moze byc pusta!
    PTimeClass receiptLimit; //limit odbioru, dwie godziny od dostarczenia
    ClientPtr sender; //klient wysylający
    ClientPtr recepient; //klient odbierający
    Size size; //wielkosc okreslona przez enumeracje
    PaczkomatPtr destination; //wskaznik na paczkomat
    bool isCollected = false;
    bool isDelievered = false;
public:
    void sendParcel(const PTimeClass &postageDate); //wyslanie paczki; setuje postageDate, dodaje recepientowi nowa paczke w Client::RecievedPackages i senderowi w Client::SentPackages. Sprawdza czy nie przekracza limitu ilosci wyslanych paczek jednosczenie
    bool collectParcel(const PTimeClass &collectionDate); //odbieranie paczki; setuje collectDate, usuwa ja senderowi z wektora; jezeli jest przeterminowana (receiptLimit < collectionDate) to usuwa ja tez recepientowi
    bool delieverParcel(const PTimeClass &delieveryDateTemp); //ustawia delieveryDate, musi byc wiekszy od postageDate
    const std::string getInfo(); //zwraca string z informacjami
    const PTimeClass &getReceiptLimit() const; //getter
    int getParcelId() const; //getter
    bool isParcelDelievered() const; //getter
    bool isParcelCollected() const; //getter
    const ClientPtr &getSender() const; //getter
    void setParcelId(int parcelId); //setter
    const ClientPtr &getRecepient() const; //getter

    Parcel(int parcelId, const ClientPtr &sender, const ClientPtr &recepient, Size size,
           const PaczkomatPtr &destination);
    virtual ~Parcel();
};


#endif //CARRENTAL_PARCEL_H
