//
// Created by barto on 10.06.2024.
//

#ifndef PACZKOMAT_CLIENTREPOSITORY_H
#define PACZKOMAT_CLIENTREPOSITORY_H

#include <vector>
#include "../model/Client.h"

class ClientRepository {
private:
    std::vector<ClientPtr> clients;
public:
    void addClient(const ClientPtr& client);
    void removeClient(const ClientPtr& client);
    const std::vector<ClientPtr> &getClients() const;
    const ClientPtr getClientByID(int id) const;

    ClientRepository();
    virtual ~ClientRepository();
};

#endif //PACZKOMAT_CLIENTREPOSITORY_H
