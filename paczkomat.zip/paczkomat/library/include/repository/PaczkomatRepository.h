//
// Created by barto on 10.06.2024.
//

#ifndef PACZKOMAT_PACZKOMATREPOSITORY_H
#define PACZKOMAT_PACZKOMATREPOSITORY_H

#include <vector>
#include "../model/Paczkomat.h"

class PaczkomatRepository {
private:
    std::vector<PaczkomatPtr> paczkomaty;
public:
    void addPaczkomat(const PaczkomatPtr& paczkomat);
    bool removePaczkomat(const PaczkomatPtr& paczkomat);
    const std::vector<PaczkomatPtr> &getPaczkomaty() const;
    const PaczkomatPtr getPaczkomatByID(int id) const;

    PaczkomatRepository();
    virtual ~PaczkomatRepository();
};

#endif //PACZKOMAT_PACZKOMATREPOSITORY_H
