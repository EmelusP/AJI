//
// Created by barto on 10.06.2024.
//

#ifndef PACZKOMAT_PARCELREPOSITORY_H
#define PACZKOMAT_PARCELREPOSITORY_H

#include <vector>
#include "../model/Parcel.h"

class ParcelRepository {
private:
    std::vector<ParcelPtr> parcels;
public:
    void addParcel(const ParcelPtr& parcel);
    void removeParcel(const ParcelPtr& parcel);
    const ParcelPtr getParcelByID(int id) const;
    const std::vector<ParcelPtr> &getParcels() const;

    ParcelRepository();
    virtual ~ParcelRepository();
};


#endif //PACZKOMAT_PARCELREPOSITORY_H
