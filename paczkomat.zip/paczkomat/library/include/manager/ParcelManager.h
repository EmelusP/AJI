//
// Created by barto on 11.06.2024.
//

#ifndef PACZKOMAT_PARCELMANAGER_H
#define PACZKOMAT_PARCELMANAGER_H

#include "../repository/ParcelRepository.h"

class ParcelManager {
private:
    ParcelRepository parcelRepo;
public:
    bool checkParcel(const ParcelPtr& parcel) const;
    int countParcels() const;
    bool createParcel(const ParcelPtr& parcel);
    bool delieverParcel(int parcelId);
    void deleteParcel(int id);
    const ParcelPtr getParcelByID(int id) const;
    const std::string getInfo(int id);

    ParcelManager();
    virtual ~ParcelManager();
};


#endif //PACZKOMAT_PARCELMANAGER_H
