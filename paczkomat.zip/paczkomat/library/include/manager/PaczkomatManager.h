//
// Created by barto on 11.06.2024.
//

#ifndef PACZKOMAT_PACZKOMATMANAGER_H
#define PACZKOMAT_PACZKOMATMANAGER_H

#include "../repository/PaczkomatRepository.h"

class PaczkomatManager {
private:
    PaczkomatRepository paczkomatRepo;
    int currentPaczkomatId = 1;
    bool expandLockers(Size size, int amount, int id);
public:
    bool checkPaczkomat(const PaczkomatPtr& paczkomat) const;
    int countPaczkomaty() const;
    bool createPaczkomat(const std::string& address, const std::string& region);
    bool addLockers(Size size, int amount, int id);
    void deleteLockers(Size size, int id);
    const PaczkomatPtr getPaczkomatByID(int id) const;
    bool deletePaczkomat(int id);
    const std::string getInfo(int id);

    PaczkomatManager();

    virtual ~PaczkomatManager();
};


#endif //PACZKOMAT_PACZKOMATMANAGER_H
