//
// Created by barto on 10.06.2024.
//

#ifndef PACZKOMAT_CLIENTMANAGER_H
#define PACZKOMAT_CLIENTMANAGER_H

#include "../repository/ClientRepository.h"
#include "../model/Client.h"
#include "../model/BusinessClient.h"
#include "../model/PrivateClient.h"
#include "PaczkomatManager.h"
#include "ParcelManager.h"

class ClientManager {
private:
    ClientRepository clientRepo;
    std::shared_ptr<PaczkomatManager> paczkomatManago;
    std::shared_ptr<ParcelManager> parcelManago;
    int currentClientId = 1;
    int currentParcelId = 1;
public:
    bool checkClient(const ClientPtr& client) const; //sprawdzamy czy client istnieje
    int countClients() const; //liczymy clientów
    const ClientPtr getClientByID(int id) const; //zwraca pointer do clienta o podanym id
    bool createClient(const std::string& firstName, const std::string& lastName, CType clientType); //tworzy clienta i dodaje go do wektora w clientRepo
    bool sendParcel(int senderId, int recepientId, Size size, int destinationId); //tworzy parcel i wysyla go (client::sendParcel)
    bool collectParcel(int recepientId, int parcelId); //odbieramy paczke o podanym id (parcelId) w imieniu clienta o podanym id (recepientId)
    void deleteClient(int id); //usuwamy clienta o podanym id z wektora w clientRepo
    const std::string getInfo(int id); //zwracamy info o cliencie o podanym id

    virtual ~ClientManager();

    ClientManager(const std::shared_ptr<PaczkomatManager> &paczkomatManago,
                  const std::shared_ptr<ParcelManager> &parcelManago);
};



#endif //PACZKOMAT_CLIENTMANAGER_H
