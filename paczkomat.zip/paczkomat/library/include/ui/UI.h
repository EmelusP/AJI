//
// Created by barto on 12.06.2024.
//

#ifndef PACZKOMAT_UI_H
#define PACZKOMAT_UI_H
#include <vector>
#include "../model/Client.h"
#include "../repository/ParcelRepository.h"
#include "../manager/ParcelManager.h"
#include "../repository/ClientRepository.h"
#include "../manager/ClientManager.h"
#include "../model/Parcel.h"
#include "../model/PrivateClient.h"
#include "../model/BusinessClient.h"
#include "../typedefs.h"
#include <plog/Log.h>
#include <plog/Initializers/RollingFileInitializer.h>

class UI {
private:
    std::vector<ClientPtr> clients;

public:
    std::shared_ptr<ParcelManager> parcelManago = std::make_shared<ParcelManager>();
    std::shared_ptr<PaczkomatManager> paczkomatManago = std::make_shared<PaczkomatManager>();
    std::shared_ptr<ClientManager> clientManago = std::make_shared<ClientManager>(paczkomatManago, parcelManago);
    void displayMenu();//zwraca informacje o możliwościach opcji menu
    int run();//uruchamia całe menu
    void addPrivateClient();//dodaje klienta prywatnego
    void addBusinessClient();//dodaje klienta biznesowego
    void sendParcel();//wysyła paczkę (nadawca,odbiorca,rozmiar,id paczkomat)
    void collectParcel();// odbiera paczki z paczkomatu (odbiorca, id paczkomat)
    void displayClients();// wyświetla wszystkie informacje o klientach
    void utworzPaczkomat();// tworzy nowy pusty paczkomat
    void usunPaczkomat();// usuwa paczkomat
    void zmianaParam();// ustawia parametry (dodaje/usuwa skrytki) 2 funkcje
    void usunKlienta(); // usuwa klienta
    void dostarczPaczke();//dostarcza paczke
    Size parametry(std::string litera);// odpowiada za przekonwertowanie rozmiaru do naszej nomenklatury
    UI();
};


#endif //PACZKOMAT_UI_H
