//
// Created by student on 09.06.24.
//

#ifndef PACZKOMAT_TYPEDEFS_H
#define PACZKOMAT_TYPEDEFS_H
#include <memory>
#include "boost/date_time/posix_time/posix_time.hpp"
#include "boost/date_time/gregorian/gregorian.hpp"
#include <string>
#include <vector>
#include <algorithm>
#include <chrono>
#include <thread>

enum Size { //enumeracja wielkości paczki i lockerow
    S = 0,
    M = 1,
    L = 2
};

enum CType { //enumeracja typu klient
    Business = 0,
    Private = 1
};


class Client;
class Lockers;
class Paczkomat;
class Parcel;

typedef std::shared_ptr<Client> ClientPtr;
typedef std::shared_ptr<Lockers> LockersPtr;
typedef std::shared_ptr<Paczkomat> PaczkomatPtr;
typedef std::shared_ptr<Parcel> ParcelPtr;
typedef boost::posix_time::ptime PTimeClass;

#endif //PACZKOMAT_TYPEDEFS_H
