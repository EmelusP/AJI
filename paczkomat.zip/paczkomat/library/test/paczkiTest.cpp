//
// Created by mrles on 15.06.2024.
//

#include <boost/test/unit_test.hpp>
#include "../include/model/Lockers.h"
#include "../include/model/Paczkomat.h"
#include "../include/model/Client.h"
#include "../include/model/BusinessClient.h"
#include "../include/model/PrivateClient.h"

BOOST_AUTO_TEST_SUITE(paczkiTestSuite)

    BOOST_AUTO_TEST_CASE(wysylaniePaczekTest)
    {
        std::shared_ptr<BusinessClient> biznesowyPtr = std::make_shared<BusinessClient>();
        std::shared_ptr<PrivateClient> prywatnyPtr = std::make_shared<PrivateClient>();

        ClientPtr johnPtr = std::make_shared<Client>("John", "Doe", 1, biznesowyPtr);
        ClientPtr janPtr = std::make_shared<Client>("Jan", "Kowalski", 2, prywatnyPtr);

        LockersPtr duzePtr = std::make_shared<Lockers>(L, 1);
        LockersPtr sredniePtr = std::make_shared<Lockers>(M, 1);

        PaczkomatPtr paczkomatPtr = std::make_shared<Paczkomat>("ABC", "00-000 wejherowo", 1);
        paczkomatPtr->addLockers(duzePtr);
        paczkomatPtr->addLockers(sredniePtr);

        ParcelPtr paczkaPtr = std::make_shared<Parcel>(1, johnPtr, janPtr, M, paczkomatPtr);
        ParcelPtr paczka2Ptr = std::make_shared<Parcel>(2, janPtr, johnPtr, S, paczkomatPtr);
        ParcelPtr paczka3Ptr = std::make_shared<Parcel>(3, janPtr, johnPtr, M, paczkomatPtr);
        ParcelPtr paczka4Ptr = std::make_shared<Parcel>(4, janPtr, johnPtr, L, paczkomatPtr);
        ParcelPtr paczka5Ptr = std::make_shared<Parcel>(5, janPtr, johnPtr, L, paczkomatPtr);

        PTimeClass data1(boost::gregorian::date(2024, 1, 1), boost::posix_time::hours(0)+boost::posix_time::minutes(1));
        PTimeClass data2(boost::gregorian::date(2024, 1, 2), boost::posix_time::hours(0)+boost::posix_time::minutes(1));
        PTimeClass data3(data2 + boost::posix_time::hours(2));
        PTimeClass data4(data2 + boost::posix_time::hours(48) + boost::posix_time::minutes(1));

        //normalny case delieveru
        BOOST_REQUIRE_EQUAL(janPtr->sendParcel(paczkaPtr, data1), false); //proba nadania nie swojej paczki
        BOOST_REQUIRE_EQUAL(johnPtr->sendParcel(paczkaPtr, data1), true); //prawidlowe wyslanie paczki
        BOOST_REQUIRE_EQUAL(johnPtr->sendParcel(paczkaPtr, data1), false); //proba ponownego wyslania paczki
        BOOST_REQUIRE_EQUAL(paczkaPtr->delieverParcel(data1), false); //dostarczenie przed czasem
        BOOST_REQUIRE_EQUAL(paczkaPtr->delieverParcel(data2), true); //odpowiednie dostarczenie
        BOOST_REQUIRE_EQUAL(paczkaPtr->getReceiptLimit(), data2 + boost::gregorian::days(2));
        BOOST_REQUIRE_EQUAL(johnPtr->getSentPackageByID(1), paczkaPtr); //sprawdzenie gettera paczki z listy sentPackages klienta
        BOOST_REQUIRE_EQUAL(johnPtr->collectParcel(1, data3), false); //case gdzie inna osoba niz reciever odbiera paczke
        BOOST_REQUIRE_EQUAL(janPtr->collectParcel(1, data4), false); //case gdzie przekroczylismy czas odbioru
        BOOST_REQUIRE_EQUAL(paczkaPtr->isParcelCollected(), false); //sprawdzamy koncowy stan paczki, tutaj zostaje ona w repozytorium, ale zostaja jej usuniete wszelkie dowiazania do klientow
        BOOST_REQUIRE_EQUAL(paczkaPtr->isParcelDelievered(), true);
        //przekraczanie limitu wyslanych paczek
        BOOST_REQUIRE_EQUAL(janPtr->sendParcel(paczka2Ptr, data1), true); //prawidlowe wyslanie paczki
        BOOST_REQUIRE_EQUAL(janPtr->sendParcel(paczka4Ptr, data1), true);
        BOOST_REQUIRE_EQUAL(janPtr->sendParcel(paczka5Ptr, data1), true);
        BOOST_REQUIRE_EQUAL(janPtr->sendParcel(paczka3Ptr, data1), false); //przekroczenie limitu
        //zapelnienie paczkomatu
        BOOST_REQUIRE_EQUAL(paczka2Ptr->delieverParcel(data2), false); //paczkomat nie ma takiego size'u
        Lockers male1(S, 1);
        LockersPtr male1Ptr = std::make_shared<Lockers>(male1);
        paczkomatPtr->addLockers(male1Ptr);
        BOOST_REQUIRE_EQUAL(paczka2Ptr->delieverParcel(data2), true); //zajmmie locker S
        BOOST_REQUIRE_EQUAL(paczka4Ptr->delieverParcel(data2), true); //zajmie locker L
        BOOST_REQUIRE_EQUAL(paczka5Ptr->delieverParcel(data2), false); //nie ma miejsca na paczke L size :(
        BOOST_REQUIRE_EQUAL(paczka4Ptr->collectParcel(data3), true); //odbieramy paczuche w czasie
        BOOST_REQUIRE_EQUAL(paczka5Ptr->delieverParcel(data2), true); //miejsce sie zwolnilo!

    }

BOOST_AUTO_TEST_SUITE_END()