//
// Created by mrles on 18.06.2024.
//

#include <boost/test/unit_test.hpp>
#include "../include/model/Lockers.h"
#include "../include/model/Paczkomat.h"
#include "../include/model/Client.h"
#include "../include/model/BusinessClient.h"
#include "../include/model/PrivateClient.h"
#include "../include/manager/ClientManager.h"
using namespace std::chrono_literals;

BOOST_AUTO_TEST_SUITE(managerTestSuite)
    BOOST_AUTO_TEST_CASE(typicalBehaviourTest)
    {
        //inicjacja managerow
        std::shared_ptr<ParcelManager> parcelManager = std::make_shared<ParcelManager>();
        std::shared_ptr<PaczkomatManager> paczkomatManager = std::make_shared<PaczkomatManager>();
        std::shared_ptr<ClientManager> clientManago = std::make_shared<ClientManager>(paczkomatManager, parcelManager);

        BOOST_REQUIRE_EQUAL(clientManago->createClient("John", "Doe", Business), true);
        BOOST_REQUIRE_EQUAL(clientManago->createClient("Joe", "Mama", Private), true);
        BOOST_CHECK(clientManago->getClientByID(1) != nullptr); //sprawdzamy ustawione id
        BOOST_CHECK(clientManago->getClientByID(2) != nullptr); //sprawdzamy ustawione id
        BOOST_REQUIRE_EQUAL(paczkomatManager->addLockers(S, 1, 1), false); //próbujemy dodać lockery do nieistniejącego paczkomatu
        BOOST_REQUIRE_EQUAL(clientManago->collectParcel(1, 1), false); //paczucha nie istnieje
        BOOST_REQUIRE_EQUAL(paczkomatManager->createPaczkomat("mila", "ABC"), true);
        BOOST_REQUIRE_EQUAL(clientManago->sendParcel(1, 2, S, 1), true); //funkcja tworzy paczke wiec powinna zwrocic true
        BOOST_REQUIRE_EQUAL(clientManago->sendParcel(1, 2, S, 2), false); //nie istnieje paczkomat, powinno zwrocic false
        BOOST_REQUIRE_EQUAL(clientManago->sendParcel(2, 1, S, 1), true); //nadajemy kolejna paczuche
        BOOST_REQUIRE_EQUAL(clientManago->sendParcel(2, 1, S, 1), true); //i kolejna
        BOOST_REQUIRE_EQUAL(clientManago->sendParcel(2, 1, S, 1), true); //i kolejna
        BOOST_REQUIRE_EQUAL(clientManago->sendParcel(2, 1, S, 1), false); //ups klient nie ma miejsca
        BOOST_REQUIRE_EQUAL(clientManago->collectParcel(2, 1), false); //paczka nie jest delievered
        BOOST_REQUIRE_EQUAL(parcelManager->delieverParcel(1), false); //nie ma miejsca na paczke w paczkomacie (lockery nie sa dodane)
        BOOST_REQUIRE_EQUAL(paczkomatManager->addLockers(S, 1, 1), true); //dodajemy skrytki
        BOOST_REQUIRE_EQUAL(clientManago->collectParcel(2, 1), false); //probujemy odebrac niedostarczona paczke
        std::cout << boost::posix_time::second_clock::local_time();
        std::this_thread::sleep_for(1000ms);
        BOOST_REQUIRE_EQUAL(parcelManager->delieverParcel(1), true); //dostarczamy paczuche
        BOOST_REQUIRE_EQUAL(paczkomatManager->addLockers(S, 1, 1), true); //probujemy dodac skrytki istniejacego rozmiaru
        BOOST_REQUIRE_EQUAL(clientManago->collectParcel(2, 1), true); //odbieramy paczuche, teraz prawidlowo
        clientManago->deleteClient(2);
        clientManago->deleteClient(1);
        BOOST_CHECK(clientManago->getClientByID(2) == nullptr); //powinien zostac usuniety, getter go nie znajduje
        parcelManager->deleteParcel(1);
        BOOST_CHECK(parcelManager->getParcelByID(1) == nullptr); //powinna zostac usunieta, getter jej nie znajduje
        paczkomatManager->deletePaczkomat(1);
        BOOST_CHECK(paczkomatManager->getPaczkomatByID(1) == nullptr); //to samo co wczesniej
    }

BOOST_AUTO_TEST_SUITE_END()