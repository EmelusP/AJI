//
// Created by student on 12.06.24.
//

#include <boost/test/unit_test.hpp>
#include "../include/model/Lockers.h"
#include "../include/model/Paczkomat.h"
#include "../include/model/Client.h"
#include "../include/model/BusinessClient.h"
#include "../include/model/PrivateClient.h"

BOOST_AUTO_TEST_SUITE(BasicModelTestSuite)

    BOOST_AUTO_TEST_CASE(TworzeniePaczkomatuTest) {

        LockersPtr malePtr = std::make_shared<Lockers>(S, 5);
        LockersPtr sredniePtr = std::make_shared<Lockers>(M, 5);
        LockersPtr duzePtr = std::make_shared<Lockers>(L, 5);
        Paczkomat paczkomat("ABC", "00-000 wejherowo", 1);

        BOOST_REQUIRE_EQUAL(malePtr->getSize(), S); //sprawdzenie kostruktorow i czy gettery getteruja
        BOOST_REQUIRE_EQUAL(malePtr->getAmountAvailable(), 5);
        BOOST_REQUIRE_EQUAL(sredniePtr->getSize(), M);
        BOOST_REQUIRE_EQUAL(sredniePtr->getAmountAvailable(), 5);
        BOOST_REQUIRE_EQUAL(duzePtr->getSize(), L);
        BOOST_REQUIRE_EQUAL(duzePtr->getAmountAvailable(), 5);

        BOOST_REQUIRE_EQUAL(paczkomat.addLockers(malePtr), true); //prawidlowe dodawanie lockerow
        BOOST_REQUIRE_EQUAL(paczkomat.addLockers(sredniePtr), true);
        BOOST_REQUIRE_EQUAL(paczkomat.addLockers(duzePtr), true);
        BOOST_REQUIRE_EQUAL(paczkomat.addLockers(malePtr), false); //proba dodania lockerow tego samego size'u
        BOOST_REQUIRE_EQUAL(paczkomat.getRegion(), "ABC"); //sprawdzenie czy gettery getteruja
        BOOST_REQUIRE_EQUAL(paczkomat.getAddress(), "00-000 wejherowo");
        BOOST_REQUIRE_EQUAL(paczkomat.occupyLocker(S), true);
        BOOST_REQUIRE_EQUAL(malePtr->getAmountAvailable(), 4); // sprawdzamy czy occupy dziala
        for (int i = 0; i < 4; i++)
            paczkomat.occupyLocker(S);
        BOOST_REQUIRE_EQUAL(paczkomat.occupyLocker(S), false); //znowu sprawdzamy occupy, tym razem skrajny przypadek gdy nie ma miejsc
        BOOST_REQUIRE_EQUAL(paczkomat.isFree(S), false);
        paczkomat.freeLocker(S);
        BOOST_REQUIRE_EQUAL(paczkomat.isFree(S), true); //sprawdzamy czy freeLocker dziala
        BOOST_REQUIRE_EQUAL(malePtr->getAmountAvailable(), 1);
        BOOST_REQUIRE_EQUAL(paczkomat.occupyLocker(S), true);
        BOOST_REQUIRE_EQUAL(malePtr->getAmountAvailable(), 0);
    }

    BOOST_AUTO_TEST_CASE(TworzenieKlientaTest) {
        std::shared_ptr<BusinessClient> biznesowyPtr = std::make_shared<BusinessClient>();
        Client klient1("John", "Doe", 1, biznesowyPtr);

        BOOST_REQUIRE_EQUAL(klient1.getFirstName(), "John"); //sprawdzenie czy konstruktor sie nie rozwala i czy gettery getteruja
        BOOST_REQUIRE_EQUAL(klient1.getLastName(), "Doe");
        BOOST_REQUIRE_EQUAL(klient1.getPersonalID(), 1);
        BOOST_REQUIRE_EQUAL(klient1.getClientType(), biznesowyPtr);

    }

    BOOST_AUTO_TEST_CASE(TworzeniePaczkiTest) {
        BusinessClient biznesowy;
        std::shared_ptr<BusinessClient> biznesowyPtr = std::make_shared<BusinessClient>(biznesowy);
        ClientPtr klient1Ptr = std::make_shared<Client>("a", "b", 1, biznesowyPtr);
        ClientPtr klient2Ptr = std::make_shared<Client>("Jan", "Kowalski", 2, biznesowyPtr);
        PaczkomatPtr paczkomatPtr = std::make_shared<Paczkomat>("A", "B", 1);
        ParcelPtr paczkaPtr = std::make_shared<Parcel>(1, klient1Ptr, klient2Ptr, M, paczkomatPtr);

        BOOST_REQUIRE_EQUAL(paczkaPtr->getParcelId(), 1); //sprawdzanie konstruktorow i getterow
        BOOST_REQUIRE_EQUAL(paczkaPtr->getSender(), klient1Ptr);
        BOOST_REQUIRE_EQUAL(paczkaPtr->getRecepient(), klient2Ptr);
        BOOST_REQUIRE_EQUAL(paczkaPtr->isParcelCollected(), false);
        BOOST_REQUIRE_EQUAL(paczkaPtr->isParcelDelievered(), false);
        BOOST_REQUIRE_EQUAL(paczkaPtr->getReceiptLimit(), boost::posix_time::not_a_date_time);
    }


BOOST_AUTO_TEST_SUITE_END()