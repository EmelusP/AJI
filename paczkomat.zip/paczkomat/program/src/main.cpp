//Introduction project.

#include <iostream>
#include "../../library/include/ui/UI.h"
using namespace std;

int main()
{
    UI ui;
    ui.run();
	return 0;
}